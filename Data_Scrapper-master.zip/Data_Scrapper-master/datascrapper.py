
#!/usr/bin/env python

"""
{This script is meant to be used for educational purposes only}
{Author_1: Ronak Salvi; more info @ shorturl.at/opyI5 }
{Author_2: Balveer Singh Vasir; more info shorturl.at/vKNR9}
{This script is open to use}
{Happy scripting!!}
"""

from bs4 import BeautifulSoup 
import requests 
import re


import xlsxwriter



i = 1 
news = "" 
r = requests.get(" ")                                              #paste your link here to scrape
soup = BeautifulSoup(r.text, 'html.parser')                         
result = soup.find_all('td', attrs = {'class':'pdsc'})

workbook = xlsxwriter.Workbook('hello1.xlsx')                      #your xls filename
worksheet = workbook.add_worksheet()


k='A'
for new in result: 
    #news += ("%s- "%i)
    news += new.text.strip()
    news += "\n"
    worksheet.write(k+str(i),news)
    k = chr(ord(k)+1)
    if k == "K":
        k="A"
        i += 1

    
    news =""
    
#print(news)
workbook.close()

 


