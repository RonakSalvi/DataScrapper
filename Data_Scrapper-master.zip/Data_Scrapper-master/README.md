# Data_Scrapper
This Script is meant for educational purposes only. Scraping data for websites depending on websites. 
Packages imported from python belong to respective owners.
